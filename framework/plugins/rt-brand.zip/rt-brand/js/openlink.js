function openUrl(url){
    if(url.length) window.open(url);
}