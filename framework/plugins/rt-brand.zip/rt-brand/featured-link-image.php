<?php
/**
 * Plugin Name: RT - Brand
 * Plugin URI: 
 * Text Domain: 
 * Domain Path: 
 * Description: Add a list brand - list link connect
 * Author: 
 * Author URI: 
 * Version: 1.0
 * License: GPLv2 or later
 * License URI: http://www.gnu.org/licenses/gpl-2.0.html
 */

if ( is_admin() )
	add_action( 'plugins_loaded', array( Featured_Link_Image_Class::get_instance(), 'plugin_setup' ) );

class Featured_Link_Image_Class
{
	/**
	 * Plugin instance.
	 *
	 * @see get_instance()
	 * @type object
	 */
	protected static $instance = NULL;

	/**
	 * URL to this plugin's directory.
	 *
	 * @type string
	 */
	public $plugin_url = '';

	/**
	 * Path to this plugin's directory.
	 *
	 * @type string
	 */
	public $plugin_path = '';

	/**
	 * Access this plugin’s working instance
	 *
	 * @wp-hook plugins_loaded
	 * @since   2012.09.13
	 * @return  object of this class
	 */
	public static function get_instance()
	{
		NULL === self::$instance and self::$instance = new self;

		return self::$instance;
	}


	/**
	 * Used for regular plugin work.
	 *
	 * @wp-hook plugins_loaded
	 * @since   2012.09.10
	 * @return  void
	 */
	public function plugin_setup()
	{

		$this->plugin_url  = plugins_url( '/', __FILE__ );
		$this->plugin_path = plugin_dir_path( __FILE__ );
		// $this->load_language( 'fli' );

		add_action( 'load-link-add.php', array( $this, 'meta_box' ) );
		add_action( 'load-link.php', array( $this, 'meta_box' ) );
		add_action( 'load-link-manager.php', array( $this, 'make_columns' ) );
		add_filter( 'get_bookmarks', array( $this, 'link_manager_order' ) );
		add_action( 'admin_footer-link-manager.php', array( $this, 'print_admin_footer' ) );
		add_action( 'admin_head-media-upload-popup', array( $this, 'print_iframe_head' ) );
		add_filter( 'attachment_fields_to_edit', array( $this, 'remove_upload_fields'), 99, 2 );
	}


	/**
	 * Constructor. Intentionally left empty and public.
	 *
	 * @see plugin_setup()
	 * @since 2012.09.12
	 */
	public function __construct()
	{
		
	}


	/**
	 * Instantiate Meta Box
	 * 
	 */
	public function meta_box()
	{
		new Featured_Link_Image_MetaBox_Class();
	}


	/**
	 * Dispatch all hooks for custom columns
	 */
	public function make_columns()
	{
		add_filter( 'manage_link-manager_columns', array( $this, 'add_id_column' ) );
		add_action( 'manage_link_custom_column', array( $this, 'add_id_column_data' ), 10, 2 );

		add_filter( 'request', array( $this, 'thumb_column_orderby' ) );
		add_filter( 'manage_link-manager_sortable_columns', array( $this, 'column_register_sortable' ) );
	}


	/**
	 * Add columns, ID and Thumbnail
	 * 
	 */
	public function add_id_column( $link_columns )
	{
		$in = array( "link_id" => "ID" );
		$link_columns = $this->array_push_after( $link_columns, $in, 0 );
		$link_columns['thumbnail'] = __( 'Thumbnail', 'fli' );

		return $link_columns;
	}


	/**
	 * Display column content
	 * 
	 * @param type $column_name
	 * @param type $id
	 * @return type
	 */
	public function add_id_column_data( $column_name, $id )
	{
		if ( $column_name == 'thumbnail' )
		{
			$val = get_bookmark_field( 'link_image', $id );
			if ( empty( $val ) )
				return;
			$img = '<img src="' . $val . '" style="max-width:50px">';
			echo $img;
		}
		if ( $column_name == 'link_id' )
		{
			$val = get_bookmark_field( 'link_id', $id );
			echo $val;
		}
	}


	/**
	 * Register column for display
	 * 
	 * @param type $columns
	 * @return string
	 */
	public function column_register_sortable( $columns )
	{
		$columns['thumbnail'] = 'link_image';
		$columns['link_id']   = 'link_id';
		return $columns;
	}


	/**
	 * Register orderby in 'request' filter
	 * 
	 * @param type $vars
	 * @return type
	 */
	public function thumb_column_orderby( $vars )
	{
		if ( isset( $vars['orderby'] ) && 'thumbnail' == $vars['orderby'] )
		{
			$vars = array_merge( $vars, array(
				'meta_key' => 'link_image',
				'orderby'  => 'meta_value_num'
			) );
		}

		return $vars;
	}

	/**
	 * Sort Links by thumbnail
	 * @global type $current_screen
	 * @param type $links
	 * @return type
	 */
	public function link_manager_order( $links )
	{
		if ( !isset( $_GET['orderby'] ) )
			return $links;

		global $current_screen;
		if ( $current_screen->id == 'link-manager' && $_GET['orderby'] == 'link_image' )
		{
			$order = ($_GET['order'] === 'asc') ? SORT_ASC : SORT_DESC;
			$this->sort_on_field( $links, 'link_image', $order );
			return $links;
		}

		return $links;
	}


	/**
	 * jQuery and CSS for the iframe popup
	 */
	public function print_iframe_head()
	{
		// Load only if fli_type defined
		if ( isset( $_GET['fli_type'] ) )
		{
			// Refresh upload screen every half second
			// Changes the "Insert into post" text and hides button "Save all changes"
			$select  = __( "Select link image", 'fli' );
			$tab     = isset( $_GET['tab'] ) ? $_GET['tab'] : "type";
			$refresh = ($tab == 'type') ? 'var mtt_t = setInterval(function(){
		$("#media-items").each(setButtonNames); 
		$("p.savebutton").css("display", "none"); 
		}, 500);' : '';

			$js = <<<EOM
		<script type="text/javascript">
		function setButtonNames() {
			jQuery(this).find('.savesend .button').val('{$select}');
		}
		jQuery(document).ready(function($){
			$('#media-items').each(setButtonNames);
			{$refresh}
		});
		</script>
EOM;
			echo $js;
		}
	}

	
	/**
	 * Set content of important field that we are hidding
	 * 
	 * @param type $form_fields
	 * @param type $post
	 * @return string
	 */
	public function remove_upload_fields( $form_fields, $post ) 
	{
	if( !isset( $_GET['fli_type'] ) )
			return $form_fields;
		
		$html = "<input type='hidden' name='attachments[".$post->ID."][url]' value='".$post->guid."'/>";

		$form_fields['url']['html'] = $html;
		$form_fields['url']['helps'] = '';
		$form_fields['url']['label'] = '';

		return $form_fields;
	}
	
	
	/*
	 * Insert $in item in position $pos inside the $src array
	 */
	private function array_push_after( $src, $in, $pos )
	{
		if ( is_int( $pos ) )
			$R = array_merge( array_slice( $src, 0, $pos + 1 ), $in, array_slice( $src, $pos + 1 ) );
		else
		{
			foreach ( $src as $k => $v )
			{
				$R[$k] = $v;
				if ( $k == $pos )
					$R       = array_merge( $R, $in );
			}
		}
		return $R;
	}


	/*
	 * Sort multidimensional array by stdClass
	 */

	private function sort_on_field( &$db, $col, $order = SORT_ASC )
	{
		$sort = array( );
		foreach ( $db as $i => $obj )
		{
			$sort[$i] = $obj->{$col};
		}
		$sorted_db  = array_multisort( $sort, $order, $db );
	}


}

/**
 * Meta Box Class
 */
class Featured_Link_Image_MetaBox_Class
{
	private $url = '';

	public function __construct()
	{
		$this->url = Featured_Link_Image_Class::get_instance()->plugin_url;

		add_action( 'add_meta_boxes', array( &$this, 'add_fli_meta_box' ) );
		//add_action( 'add_meta_boxes_link', array( &$this, 'add_fli_meta_box' ) );

		add_action( 'admin_print_scripts', array( &$this, 'admin_scripts' ) );
		add_action( 'admin_print_styles', array( &$this, 'admin_styles' ) );
	}


	public function admin_scripts()
	{
		wp_enqueue_script( 'fli-upload-js', $this->url . 'js/uploader.js', array( 'jquery', 'media-upload', 'thickbox' ) );
	}


	public function admin_styles()
	{
		wp_enqueue_style( 'thickbox' );
		wp_enqueue_style( 'fli-upload-css', $this->url . 'css/uploader.css' );
	}


	/**
	 * Adds the meta box container
	 */
	public function add_fli_meta_box()
	{
		add_meta_box(
				'featured_link_image_meta_box'
				, __( 'Featured Link Image', 'fli' )
				, array( &$this, 'render_meta_box_content' )
				, 'link'
				, 'side'
				, 'default'
		);
	}


	/**
	 * Render Meta Box content
	 */
	public function render_meta_box_content()
	{
		global $link;

		$img        = (isset( $link->link_image ) && '' !== $link->link_image) ? '<img src="' . $link->link_image . '" class="link-featured-image">' : '';
		$class_hide = ('' === $img) ? 'hide-image-text' : '';
		$class_show = ('' !== $img) ? 'hide-image-text' : '';
		$spanimg    = sprintf( '<div id="my-link-img">%s</div>', $img );
		?>
		<table>
			<tr>
				<td>
					<span class="link-help-text <?php echo $class_show; ?>">
						<?php _e( 'After selecting/uploading, the image address will be inserted inside the Advanced->Image Address field.', 'fli' ); ?>
					</span>
				</td>
			</tr>
			<tr>
				<td>
					<a id="upload_image_button" class="<?php echo $class_show; ?>" href="#">
						<?php _e( 'Set link image', 'fli' ); ?>
					</a>
				</td>
			</tr>
			<tr>
				<td><?php echo $spanimg; ?></td>
			</tr>
			<tr>
				<td>
					<a href="#" id="remove-image-text" class="<?php echo $class_hide; ?>">
						<?php _e( 'Remove image', 'fli' ); ?>
					</a>
				</td>
			</tr>
		</table>
		<?php
	}

}

/*-----------------------------------------------------------------------------------

	Widget Name: RT - Brand

-----------------------------------------------------------------------------------*/

if ( ! function_exists( 'rt_brand' ) ) {
	add_filter( 'pre_option_link_manager_enabled' , '__return_true');
	add_action( 'widgets_init' , 'rt_brand' );
	function rt_brand() {
		register_widget( 'RT_Brand' );
	}
}

class RT_Brand extends WP_Widget {

	function __construct() {
		parent::__construct(
			'rt_brand', // Base ID
			__( 'RT - Brand' , RT_LANGUAGE ), // Name
			array( 'description' => __( 'Display link connect' , RT_LANGUAGE ) ) // Args
		);
	}

	function widget( $args, $instance ) {

		extract( $args );
		extract( wp_parse_args( (array)$instance, array(
			'title'         => '',
			'layout'        => 'layout_1',
			'category_id'   => false,
			'images'        => false,
			'description'   => false
		) ) );

		$title = apply_filters( 'widget_title', $instance['title'] );
		$category_id = ! empty( $instance['category_id'] )? $instance['category_id'] : '';
		
		echo $before_widget;
		if ( ! empty( $title ) )
			echo $before_title . $title . $after_title;
			
		$layout         = $instance['layout'];
		$args           = array('category' => $category_id);
		$bookmarks      = get_bookmarks( $args );

		echo '<div class="widget-content-link">';
		if( $layout == 'layout_1' ) {
			echo '<select>';
				echo '<option value="">' . __( 'Choose link', RT_LANGUAGE ) . '</option>';
				foreach ( $bookmarks as $bookmark ) {
					$link_name = isset( $instance['description'] ) ? $bookmark->link_name . ' - ' . $bookmark->link_description : $bookmark->link_name;
					
					echo '<option value="'.$bookmark->link_url.'">' . $link_name . '</option>';
				}
			echo '</select>';
		} elseif ( $layout == 'layout_2' ) {
			foreach ( $bookmarks as $bookmark ) { 
				echo '<li><a href="'. $bookmark->link_url .'" target="'. $bookmark->link_target .'">';
				if( isset($instance['images']) ) {
					echo '<img src="'. $bookmark->link_image .'">';
				}
				echo $bookmark->link_name;
				if( isset($instance['description']) ) {
					echo ' - '.$bookmark->link_description;
				}
				echo '</a></li>';
			}
		}
		echo '</div>';
		echo $after_widget;
	}

	function update( $new_instance, $old_instance ) {
		return $new_instance;
	}

	function form( $instance ) {
		$default = array(
			'title'         => '',
			'layout'        => 'layout_1',
			'category_id'   => false,
			'images'        => false,
			'description'   => false
		);
		$instance       = wp_parse_args( (array) $instance, $default );

		// Get all term link_category
		$terms = get_terms( 'link_category', array( 'hide_empty' => false ) ) ;
		?>
		<p>
			<label for="<?php echo $this->get_field_id('title'); ?>"><?php _e( 'Title', RT_LANGUAGE ) ; ?>:</label>
			<input type="text" class="widefat" id="<?php echo $this->get_field_id('title'); ?>" name="<?php echo $this->get_field_name('title'); ?>" value="<?php echo $instance['title']; ?>" />
		</p>
		<p>
			<label for="<?php echo $this->get_field_id('layout'); ?>"><?php _e( 'Choose layout', RT_LANGUAGE ) ; ?>:</label>
			<select id="<?php echo $this->get_field_id('layout'); ?>" name="<?php echo $this->get_field_name('layout'); ?>" class="widefat" style="width:100%;">
				<option value="layout_1" <?php selected( 'layout_1' , $instance['layout']); ?>><?php _e( 'Dropdown menu', RT_LANGUAGE ) ; ?></option>
				<option value="layout_2" <?php selected( 'layout_2' , $instance['layout']); ?>><?php _e( 'List', RT_LANGUAGE ) ; ?></option>
			</select>
		</p>
		<p>
			<label for="<?php echo $this->get_field_name( 'category_id' ); ?>"><?php _e( 'Link Category', RT_LANGUAGE ) ; ?>:</label> 
			<select id="<?php echo $this->get_field_id( 'category_id' ); ?>" name="<?php echo $this->get_field_name( 'category_id' ); ?>" class="widefat" style="width:100%;">
				<option value=""><?php _e( 'All Link', RT_LANGUAGE ) ; ?></option>
				<?php if ( count( $terms ) ) : ?>
					<?php foreach( $terms as $term ): ?>
						<option value="<?php echo $term->term_id; ?>" <?php selected( $term->term_id , $instance['category_id']); ?>>
							<?php echo $term->name; ?>
						</option>
					<?php endforeach; ?>
				<?php endif;?>
			</select>
		</p>
		<p>
			<input class="checkbox" type="checkbox" <?php checked($instance['description'], 'on'); ?> id="<?php echo $this->get_field_id('description'); ?>" name="<?php echo $this->get_field_name('description'); ?>" />
			<label for="<?php echo $this->get_field_id('description'); ?>"><?php _e( 'Show Description', RT_LANGUAGE ); ?></label>
		</p>
		<?php
		if( $layout == 'layout_2' ) {
		?>
			<p>
				<input class="checkbox" type="checkbox" <?php checked($instance['images'], 'on'); ?> id="<?php echo $this->get_field_id('images'); ?>" name="<?php echo $this->get_field_name('images'); ?>" />
				<label for="<?php echo $this->get_field_id('images'); ?>"><?php _e( 'Show Image', RT_LANGUAGE ); ?></label>
			</p>
		<?php
		}
	}
}