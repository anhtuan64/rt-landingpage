<?php

ITSEC_Modules::register_module( 'ssl', dirname( __FILE__ ) );
