<?php

require_once( 'class-itsec-wordpress-tweaks.php' );

ITSEC_WordPress_Tweaks::activate();
