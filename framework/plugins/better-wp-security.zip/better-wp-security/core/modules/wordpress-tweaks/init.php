<?php

ITSEC_Modules::register_module( 'wordpress-tweaks', dirname( __FILE__ ), 'default-active' );
