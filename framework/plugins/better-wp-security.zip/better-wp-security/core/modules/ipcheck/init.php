<?php

ITSEC_Modules::register_module( 'network-brute-force', dirname( __FILE__ ), 'default-active' );
