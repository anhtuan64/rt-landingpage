<?php

ITSEC_Modules::register_module( 'system-tweaks', dirname( __FILE__ ) );
