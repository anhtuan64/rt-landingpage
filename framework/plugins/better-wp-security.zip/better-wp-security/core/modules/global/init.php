<?php

ITSEC_Modules::register_module( 'global', dirname( __FILE__ ), 'always-active' );
