<?php
/*
Plugin Name: RT - Advanced Custom Search
Plugin URI: http://thietkewebmienphi.com
Description: 
Version: 1.0
Author: Lucas 
Author URI: http://ghot.net/

	Copyright (c) 2015 Lucas (http://ghot.net)
	RT - Customer Support is released under the GNU General Public License (GPL)
*/

include 'function.php';

