<?php
  // silence is golden