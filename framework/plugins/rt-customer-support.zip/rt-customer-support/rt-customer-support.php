<?php
/*
Plugin Name: RT - Customer Support
Plugin URI: http://thietkewebmienphi.com
Description: This plugin only support with RT customer. If you are developer, you should deactivate it to config theme of RT company
Version: 1.0
Author: Lucas 
Author URI: http://ghot.net/

	Copyright (c) 2015 Lucas (http://ghot.net)
	RT - Customer Support is released under the GNU General Public License (GPL)
*/

// Only run the code if we are in the admin
if ( is_admin() ) :

/**
 *
 * Rt Remove Menu
 *
 * @param    
 * @return  
 *
 */
if ( ! function_exists( 'rt_remove_menus' ) ) {
	function rt_remove_menus(){
		global $smof_data;

		if ( $smof_data['theme_setup_customer_support'] ) {
			// Remove default menu:
			// -------------------------------------------------------
			remove_menu_page( 'upload.php' );                	//Media
			remove_menu_page( 'edit-comments.php' );          	//Comments
			remove_menu_page( 'plugins.php' );					//Plugins
			remove_menu_page( 'update-core.php' );            
			remove_menu_page( 'tools.php' );                 	//Tools

			// Remove child menu (submenu)
			// -------------------------------------------------------
			remove_submenu_page( 'index.php', 'update-core.php' ); // Update
			remove_submenu_page( 'themes.php', 'theme-editor.php' ); // Theme editor
			remove_submenu_page( 'themes.php', 'themes.php' ); // Customize

			// Remove custom menu (submenu)
			// -------------------------------------------------------
			if ( is_plugin_active('fusion-core/fusion-core.php') ) {
				remove_menu_page( 'edit.php?post_type=tribe_events' ); 
				remove_menu_page( 'edit.php?post_type=avada_portfolio' ); 
				remove_menu_page( 'edit.php?post_type=avada_faq' ); 
				remove_menu_page( 'edit.php?post_type=slide' );
				remove_menu_page( 'edit.php?post_type=themefusion_elastic' );
			}
			return;
		} elseif ( $smof_data['theme_setup_developer_level_1'] ) {
			if ( is_plugin_active('fusion-core/fusion-core.php') ) {
				remove_menu_page( 'edit.php?post_type=tribe_events' ); 
				remove_menu_page( 'edit.php?post_type=avada_portfolio' ); 
				remove_menu_page( 'edit.php?post_type=avada_faq' ); 
				remove_menu_page( 'edit.php?post_type=slide' );
				remove_menu_page( 'edit.php?post_type=themefusion_elastic' );
			}
			return;
		}
	}
	add_action( 'admin_menu', 'rt_remove_menus' );
}

/**
 *
 * Hook Admin Body Class
 *
 * @param    
 * @return  
 *
 */
if ( ! function_exists( 'rt_add_admin_body_class' ) ) {
	function rt_add_admin_body_class( $classes ) {
		global $smof_data;

		// Add Class check display with customer
		if ( $smof_data['theme_setup_customer_support'] ) {
			$classes .= ' customer-support';
			return $classes;
		} elseif ( $smof_data['theme_setup_developer_level_1'] ) {
			$classes .= ' dev-1';
			// return $classes;
		}

		return $classes;
	}
	add_filter( 'admin_body_class', 'rt_add_admin_body_class' );
}

/**
 *
 * Admin page enqueue script
 *
 * @param    
 * @return  
 *
 */
if ( ! function_exists( 'rt_enqueue_script_admin' ) ) {
	function rt_enqueue_script_admin() {
		wp_enqueue_style( 'rt-admin-style', plugin_dir_url( __FILE__ ) . 'assets/css/admin-style.css', false, '1.0.0' );
	}
	add_action( 'admin_enqueue_scripts', 'rt_enqueue_script_admin' );
}


// End if for is_admin
endif;
